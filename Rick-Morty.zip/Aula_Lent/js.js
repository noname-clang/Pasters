function soma(a, b) {
  return a + b;
}
console.log(soma(10, 2));

function multiplicar(a,b)
{
    return a*b
}
