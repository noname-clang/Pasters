const MinhaDiv = document.getElementById('personagem-container')
const MinhaDiv2 = MinhaDiv.getElementsByTagName('img')

document.addEventListener('DOMContentLoaded',()=>{
    const BaseUrl = "https://swapi.dev/api/people"
    fetch(BaseUrl)
    .then((response)=>{
        if(!response.ok)
        {
        throw new Error ('Erro de Rede! Codigo :' + response.status)
         }
        return response.json()
    })
    .then((data)=>{
        console.log(data.results[0].name)
        RendereizarPersonagens(data)
    })
    .catch((err)=> console.log(err))
})
function RendereizarPersonagens(itens){
    
itens.results.forEach((element , index) => {
    console.log(index)
    const DivDoPersonagem = document.createElement('div')
    DivDoPersonagem.innerHTML = `
    <div id="personagem-caixa" class="personagem-caixa"> 
        <img id="noname" src="./image/perso${index}.png" >
        <div>
            <h3>${element.name}</h3>
        </div>
    </div>
    `;
    DivDoPersonagem.addEventListener('click',()=>{
       DetalhePersonagens(index)
    })
    DivDoPersonagem.classList.add('personagem')
    MinhaDiv.appendChild(DivDoPersonagem)
});
}

MinhaDiv.addEventListener('mouseover',()=>{
    console.log(MinhaDiv)
})

function DetalhePersonagens(index){
    console.log(index)
    window.location.href = `./person.html?index=${index}`
}