import data from './data.json' assert{'type': 'json'}


console.log(data)
const button = document.getElementById("login")


button.addEventListener('click',(e)=>{
    e.preventDefault()
    const usuario = document.getElementById("user").value
    const senha = document.getElementById("password").value

    TryLogin(data,usuario,senha);

})

function TryLogin(data,usuario, senha){    
   const login = data.find((element)=>
        element.usuario == usuario && element.senha == senha
    )
    if(login)
    {
        window.location = '../index.html'
    }
    else
    alert(`User Not Found`)
}