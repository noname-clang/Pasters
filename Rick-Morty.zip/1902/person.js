const MinhaDiv = document.getElementById('personagem-container')



document.addEventListener('DOMContentLoaded' , ()=>{
    const UrlParam = new URLSearchParams(window.location.search)
    const ParamIndex = UrlParam.get('index')

    const url = `https://swapi.dev/api/people/${parseInt(ParamIndex)+1}/`
    console.log(url)
    fetch(url)
    .then((response) =>{
        if(!response.ok)
        throw new Error('Codigo :'+response.status)

        return response.json()
    })
    .then((data)=>{
        personagem(data,ParamIndex)
    })
    .catch((err)=>
    {
        console.log(err)
    })
})

function personagem(item,index){
 const personagemimagem = document.querySelector('.personagem-img')
 const nome = document.querySelector('.nome')
 const altura = document.querySelector('.altura')
 const peso = document.querySelector('.peso')
 const genero = document.querySelector('.genero')
 const cordocabelo = document.querySelector('.cor-cabelo')
 const cordoolho = document.querySelector('.cor-olho')
 const corpele = document.querySelector('.cor-pele')
 const datadenascimento = document.querySelector('.data-nascimento')
        personagemimagem.src = `./image/perso${index}.png `
        nome.innerHTML = `Nome: ${item.name}`
        altura.innerHTML = `Altura: ${item.height}cm`
        peso.innerHTML = `Peso: ${item.mass}`
        genero.innerHTML = `Genero: ${item.gender}`
        cordocabelo.innerHTML = `Cor Do Cabelo: ${item.hair_color}`
        cordoolho.innerHTML = `Cor Do Olhos: ${item.eye_color}`
        corpele.innerHTML = `Cor Da Pele: ${item.skin_color}`
        datadenascimento.innerHTML = `Data Aniversario: ${item.birth_year}`
       
}