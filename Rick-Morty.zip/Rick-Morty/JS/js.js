// "characters": "https://rickandmortyapi.com/api/character",
//   "locations": "https://rickandmortyapi.com/api/location",
//   "episodes": "https://rickandmortyapi.com/api/episode"

const Page = 2
const BaseUrl = 'https://rickandmortyapi.com/api/'

const LoadCharacter = async () =>{
    const Resposta = await fetch(`${BaseUrl}character`)
    const Data = await Resposta.json()
    const LimitData = Data.results.slice(0,6)
    return {results: LimitData}
}

const LoadLocation = async () =>{
    const Resposta = await fetch(`${BaseUrl}location`)
    return await Resposta.json()
}

const LoadEpisodes = async () =>{
    const Resposta = await fetch(`${BaseUrl}episode`)
    return await Resposta.json()
}

const LoadAllWithPromiseAll = async () =>{
    const [character,location,episode] = await Promise.all([
        LoadCharacter(),
        LoadLocation(),
        LoadEpisodes()
    ])

    ShowCharacter(character.results)
    // ShowCharacter(location.results)
    // ShowCharacter(episode.results)
}

LoadAllWithPromiseAll()

function ShowCharacter(characters){
    const charactercontainer = document.getElementById("character-container")
    characters.map((character,index) =>{
        const DivCharacter = document.createElement('div')
        DivCharacter.innerHTML = `
        <img src="${character.image}" alt="imagemdopersonagem">
        <article>
        <h3>${character.name} </h3>
        <span id="chcstatus${index}">${character.status}</span><br>
        <span>${character.species}</span>
        <span class="location">Location :</span>
        <a href="${character.location.url}">${character.location.name}</a>
    
        <span class="origin">Origin</span>
        <a href="${character.origin.url}">${character.origin.name}</a>
    
        </article>
        `
        let aliveorno =  document.getElementById("chcstatus"+(index))
        console.log(aliveorno)
        DivCharacter.classList.add('character-box')

        charactercontainer.appendChild(DivCharacter)
    })
    
}