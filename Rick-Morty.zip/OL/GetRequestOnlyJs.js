function SendGetRequest(url) {
    return fetch(url)
        .then(response => response.json())
        .then(data => {
            return data;
        })
        .catch(error => {
            console.error('Error:', error);
            return 'caiu no catch de SendGetRequest ';
        });
}
async function GetRandomCategory() {
    try {
        const PrimeiraRequest = await SendGetRequest('https://api.chucknorris.io/jokes/categories');

        if (Array.isArray(PrimeiraRequest)) {
            const randIndex = Math.floor(Math.random() * PrimeiraRequest.length);
            const name = PrimeiraRequest[randIndex];
            
            return name;
        } else {
            console.error('Unexpected response format:', PrimeiraRequest);
            return 'Deu merda no else GetRandomCategory ';
        }
    } catch (error) {
        console.error('Error:', error);
        return 'caiu no catch de GetRandomCategory ';
    }
}
async function ExecuteAsyncFunction() {
    const randomCategory = await GetRandomCategory();
    return SendGetRequest('https://api.chucknorris.io/jokes/random?category=' + randomCategory);
}
async function RunAll() {
    const result = await ExecuteAsyncFunction();
    console.log(result);
}

RunAll();