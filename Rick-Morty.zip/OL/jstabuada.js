const numero = document.querySelector("#inNumero")
let tabuada = document.getElementById("outabuada")
const btnmostrar = document.querySelector("#btnmostrar")

btnmostrar.addEventListener(`click` , ()=> 
{
    let numero2 = Number(numero.value)
    if(numero2 === 0 || isNaN(numero2))
    {
    alert ("BOTA NUMEROBESTA")
        numero.focus()
        return;
    }
   let resposta = ''
    for(let i = 0 ; i <= 10 ; i ++)
     resposta = `${resposta+ numero2} x ${i} = ${numero2 * i} <br>`;
    tabuada.innerHTML = resposta
})