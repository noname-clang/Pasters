let testarbesteira = {

    nome: `Lucas`,
    idade : 11 ,
    endereco:[

        {

            tipo : "Residencial",
            rua: "Rua A",
            cidade: "Maceio"
        },
        
        {

            tipo : "Comercial",
            rua: "Rua B",
            cidade: "Salvador"
        }
    ],
    retornaosdadosdoendereco(i){
        return `Endereco Possui tipo : ${this.endereco[i].tipo} Se Localiza Na Rua ${this.endereco[i].rua} Cidade : ${this.endereco[i].cidade}`
    },

    RetornarTodos(){
       
        for(let i = 0 ; i < this.endereco.length ; i++)
        console.log(this.retornaosdadosdoendereco(i))

    }

}

console.log(testarbesteira.RetornarTodos())