    let produtos = [{ nome: 'Camiseta', categoria: 'Roupas' }, { nome: 'Celular', categoria: 'Eletrônicos' }, { nome: 'Calca', categoria: 'Roupas' }];
    let precos = [{ nome: 'Camiseta', preco: 20 }, { nome: 'Celular', preco: 500 }, { nome: 'Calca', preco: 200 }];
    let quantidades = [3, 1];

    function AtualizarPrecos() {
        produtos.forEach((inutil, i) => {
            if(i < precos.length)
            inutil.preco = precos[i].preco;
        });
      }
      
      function FiltrarCategoria(categoria)
      { 
        let NovoArray = [];
             produtos.forEach((inutil, i) => {
            if( inutil.categoria == categoria)
            NovoArray.push(produtos[i]) 
           
            });
        return NovoArray    
      }
      function SomarPreco() {
        let NovoResult = '';
        let NovoValor = 0 ;
        produtos.forEach((produto, i) => {
            if (i < quantidades.length) {
                 NovoValor += produto.preco * quantidades[i];
                NovoResult += `Produto: ${produto.nome} Novo Valor = ${NovoValor}\n`;
            }
        });
    
        return NovoResult;
    }
      AtualizarPrecos();
      console.log(produtos);
      console.log("=============================");
      console.log(FiltrarCategoria('Roupas'));
      console.log("=============================");
      console.log(SomarPreco());