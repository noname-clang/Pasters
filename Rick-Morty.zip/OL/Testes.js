var objeto = { nome: "Bob", idade: 35 };
var jsonString = JSON.stringify(objeto)
console.log(jsonString)