function CheckNumber(n)
{

    return new Promise((resolve,reject) =>{
            if(n >20)
            resolve(`Numero é maior que 20`)
            else
            reject(new Error (`Numero Invalido`))
    })
}

const num1 = CheckNumber(25)
const num2 = CheckNumber(10)

num1.then((value) =>{
console.log(`Resultado: ${value}`)

})
.catch((err) =>{
    console.log(`Error: ${err}`)
    
    })

    num2.then((value) =>{
        console.log(`Resultado: ${value}`)
        
        })
        .catch((err) =>{
            console.log(`Error: ${err}`)
            
            })


            console.log(`passamos o async`)