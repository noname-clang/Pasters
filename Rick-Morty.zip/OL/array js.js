 const array = [21,6,84,24,86,11]
// console.log(array)
// array.push(22)
// console.log(array)
// array.unshift(55)
// console.log(array)
// array.pop()
// console.log(array)
// array.shift()
// console.log(array)
// array.splice(3,1) //// index e quanto remover dele em diante
// console.log(array)
// console.clear()


// array.forEach((elements , i)=>(

//  console.log(`${i} - ${elements}`)

// ))
// const ListarDados = (elements) => console.log(elements)
// array.forEach(ListarDados)



// var novoarray = array.map((elements)=>(elements * 3))
// console.log(`amem : ${novoarray}`)

const MaioresQue30  = array.find((elements,i)=>(
    elements[i] = elements >30
))

console.log(MaioresQue30)

const MaioresQue21  = array.filter((elements,i)=>(
    elements >21
))

console.log(MaioresQue21)