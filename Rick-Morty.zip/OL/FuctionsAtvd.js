let array = [21, 6, 84, 24, 86, 11, 39, 59, 96, 53]
let palavras = ["sol", "livro", "lua", "cadeira", "mesa", "mar"]
let newarray = [] ;
let numerosarray = [1, 2, 3, 4, 5]
let resultadosoma = 0 ; 

function VerificarMaiorQueZero(x)
{
   x >= 0 ? 1 : 0
}
function DobraoArray ()
{
    for(let i = 0 ; i< array.length ; i ++)
        array[i] = array[i] * 2 
   console.log (`========================================`)
   console.log(array)
   console.log (`========================================`)
}

DobraoArray()

function RemoverMenorQue3Letras ()
{

    for(let i = 0 ; i< palavras.length ; i ++)
     newarray = palavras.filter(word => word.length > 3);
    console.log(newarray)
    console.log (`========================================`)
}

RemoverMenorQue3Letras()
function SomaDosNumerosEmArray ()
{

    for(let i = 0 ; i< numerosarray.length ; i ++)
        resultadosoma = resultadosoma + numerosarray[i];
    console.log(resultadosoma)
    console.log (`========================================`)
}
SomaDosNumerosEmArray()


function ImportantMath(trueorfalse , index)
{
    switch(trueorfalse)
    {
        case "true":
        return numerosarray[index] *3 
        case "false":
        return numerosarray[index] *2 
        default: 
        return  "Tu é burro porra ?"
    }
}
let numerosarraydobrado = [] ; 
let numerosarraytriplo = [] ; 
let slaoq = [];
function ArrayUnique()
{
    for(let i = 0 ; i < numerosarray.length; i ++)
    {
        numerosarraydobrado[i] = ImportantMath("false", i)
        numerosarraytriplo[i] = ImportantMath("true", i)
      
    }
        
    for(let i = 0 ; i < numerosarraydobrado.length; i ++)
    slaoq.push(numerosarraydobrado[i])
    for(let i = 0 ; i < numerosarraytriplo.length; i ++)
    slaoq.push(numerosarraytriplo[i])

    return slaoq
}
console.log(ArrayUnique())