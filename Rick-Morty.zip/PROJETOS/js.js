// alert(`Olá Mundo`)
document.addEventListener('DOMContentLoaded',()=>{
       const url = `https://api.chucknorris.io/jokes/categories`
       fetch(url)
       .then(response => response.json() )
       .then(data => GerarCategorias(data))
})

function GerarCategorias(categorias)
{
  const select = document.getElementById(`opcao`)
  categorias.map((elemento)=>{
    const opcoes = document.createElement('option')
      opcoes.innerHTML = `${elemento}`
      opcoes.id = elemento
      select.appendChild(opcoes)
  })
}
const botao = document.getElementById(`btn`)
const piada = document.getElementById(`texto`)
botao.addEventListener('click' , ()=>{
  const select = document.getElementById(`opcao`).value
    console.log(select)
    const url = `https://api.chucknorris.io/jokes/random?category=${select}`
    fetch(url)
    .then((response)=>{
     return   response.json()
    }
    )
    .then(data=>AlterarPiada(data.value)
    )
})
function AlterarPiada(piadas)
{

  piada.innerHTML = piadas
}